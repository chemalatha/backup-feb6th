package plugin.google.maps;

import android.graphics.Bitmap;

public interface AsyncLoadImageInterface {
  public void onPostExecute(Bitmap image) ;
}
